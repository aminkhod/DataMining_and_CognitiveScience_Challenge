# Uber-Data-Analysis
Analyzed Uber pickups in the New York city and created visualizations to get insights on user journeys by months, hours using Python libraries
