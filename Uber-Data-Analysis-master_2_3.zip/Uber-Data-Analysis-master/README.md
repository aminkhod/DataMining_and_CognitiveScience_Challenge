# Uber-Data-Analysis 
In this case, we help those uber drivers. When we search some information online about what uber drivers care about we find out that they are sometimes confused about where to go when they don't have passengers and that of course would cause lots of waste of time and money. So this time, our group want to help uber drivers find out where should they go to find potential business when they don't have passengers during specific time period.

If we can figure out how to deal with the demand, it will be a huge progress for uber drivers and of course uber. They can create plenty of value if the drivers always know what they should do and where they should go.
