# uber-data-analysis

Data Analysis of Uber trip data available in GitHub using Python, Pandas, and Jupyter Notebook. Seaborn and matplotlib visualization tools are used to analyse and develop different plots.
