# Data-Analysis-of-Uber-trip-data-using-Python-with-Pandas
Data Analysis of Uber trip data using Python with Pandas based on a you tube video and his github 
## Completed
Video link : https://www.youtube.com/watch?v=Q73ADVZCqSU&t=1361s <br>
GitHub link : https://github.com/mnd-af/src/blob/master/2017/06/04/Uber%20Data%20Analysis.ipynb
