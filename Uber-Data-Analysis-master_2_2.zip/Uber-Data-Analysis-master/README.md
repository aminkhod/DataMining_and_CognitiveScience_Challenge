# Uber-Data-Analysis


click [here](http://nbviewer.jupyter.org/github/seyunkim/Uber-Data-Analysis/blob/master/ATG_data_science_take_home_Analytics_1-30-2018/ATG_data_science_take_home_DS_analytics_track.ipynb)
for access to the notebook
